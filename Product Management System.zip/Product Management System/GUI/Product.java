package GUI;

import Entity.*;
import File.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Product extends JFrame implements ActionListener {
    Font font30B = new Font("Segoe UI", Font.BOLD, 30);
    Font font20 = new Font("Segoe UI", Font.PLAIN, 20);
    Font font15 = new Font("Segoe UI", Font.PLAIN, 15);

    JTextField name, id, phoneNumber, productName;
    JTextArea textArea;
 

    JPanel topPanel, leftPanel, rightPanel, bottomPanel;

    // 1. Added saveBtn here
    JButton deleteBtn, addBtn, updateBtn, clear, saveBtn;

    Cursor cursor = new Cursor(Cursor.HAND_CURSOR);

    CustomerList customers = new CustomerList();

    public Product() {
        super("Product page");
        this.setSize(1000, 700);
        this.setLocationRelativeTo(null);
        this.setLayout(null);
        this.setResizable(false);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        topPanel = new JPanel();
        topPanel.setBounds(0, 0, 1000, 80);
        topPanel.setLayout(null);

        JLabel title = new JLabel("Welcome to Product Page");
        title.setBounds(200, 15, 700, 50);
        title.setFont(font30B);
        topPanel.add(title);
        this.add(topPanel);

        leftPanel = new JPanel();
        leftPanel.setBounds(0, 80, 600, 550);
        leftPanel.setLayout(null);
        leftPanel.setBackground(Color.decode("#8BA8B7")); 

        int vPos = 80;
        int gap = 50;
        int lblsize = 160;
        int txtfieldsize = 300;

        JLabel nameLabel = new JLabel("Customer Name");
        nameLabel.setBounds(40, vPos, lblsize, 30);
        nameLabel.setFont(font20);
        leftPanel.add(nameLabel);

        name = new JTextField();
        name.setBounds(220, vPos, txtfieldsize, 30);
        name.setFont(font20);
        leftPanel.add(name);

        vPos += gap;
        JLabel idLabel = new JLabel("Product ID");
        idLabel.setBounds(40, vPos, lblsize, 30);
        idLabel.setFont(font20);
        leftPanel.add(idLabel);

        id = new JTextField();
        id.setBounds(220, vPos, txtfieldsize, 30);
        id.setFont(font20);
        leftPanel.add(id);

        vPos += gap;
        JLabel phoneLabel = new JLabel("Phone Number");
        phoneLabel.setBounds(40, vPos, lblsize, 30);
        phoneLabel.setFont(font20);
        leftPanel.add(phoneLabel);

        phoneNumber = new JTextField();
        phoneNumber.setBounds(220, vPos, txtfieldsize, 30);
        phoneNumber.setFont(font20);
        leftPanel.add(phoneNumber);

        vPos += gap;
        JLabel productLabel = new JLabel("Product Name");
        productLabel.setBounds(40, vPos, lblsize, 30);
        productLabel.setFont(font20);
        leftPanel.add(productLabel);

        productName = new JTextField();
        productName.setBounds(220, vPos, txtfieldsize, 30);
        productName.setFont(font20);
        leftPanel.add(productName);

        int btnhpos = 60;
        int btnhgap = 130;
        int btnvpos = 400;

        // --- Add Button ---
        addBtn = new JButton("Add");
        addBtn.setBounds(btnhpos, btnvpos, 100, 30);
        addBtn.setFont(font20);
        addBtn.setBackground(new Color(87, 70, 229));
        addBtn.setForeground(Color.WHITE);
        addBtn.setCursor(cursor);
        addBtn.addActionListener(this);
        leftPanel.add(addBtn);

        // --- Delete Button ---
        btnhpos += btnhgap;
        deleteBtn = new JButton("Delete");
        deleteBtn.setBounds(btnhpos, btnvpos, 120, 30);
        deleteBtn.setFont(font20);
        deleteBtn.setBackground(Color.RED);
        deleteBtn.setForeground(Color.WHITE);
        deleteBtn.setCursor(cursor);
        deleteBtn.addActionListener(this);
        leftPanel.add(deleteBtn);

        // --- Update Button ---
        btnhpos += btnhgap;
        updateBtn = new JButton("Update");
        updateBtn.setBounds(btnhpos, btnvpos, 100, 30);
        updateBtn.setFont(font20);
        updateBtn.setBackground(new Color(87, 70, 229));
        updateBtn.setForeground(Color.WHITE);
        updateBtn.setCursor(cursor);
        updateBtn.addActionListener(this);
        leftPanel.add(updateBtn);

        // --- 2. NEW Save Button Added Here ---
        btnhpos += btnhgap; // Calculate position (450)
        saveBtn = new JButton("Save");
        saveBtn.setBounds(btnhpos, btnvpos, 100, 30);
        saveBtn.setFont(font20);
        saveBtn.setBackground(new Color(40, 167, 69)); // Green Color
        saveBtn.setForeground(Color.WHITE);
        saveBtn.setCursor(cursor);
        saveBtn.addActionListener(this);
        leftPanel.add(saveBtn);


        clear = new JButton("Clear");
        clear.setBounds(370, 330, 90, 30);
        clear.setFont(font20);
        clear.setBackground(Color.RED);
        clear.setForeground(Color.WHITE);
        clear.setCursor(cursor);
        clear.addActionListener(this);
        leftPanel.add(clear);

        this.add(leftPanel);

        rightPanel = new JPanel();
        rightPanel.setBounds(600, 80, 400, 550);
        rightPanel.setLayout(null);
        rightPanel.setBackground(new Color(102, 178, 255));

        textArea = new JTextArea();

        textArea.setBounds(13, 13, 360, 525);

        textArea.setFont(font15);

        textArea.setEditable(false);

        textArea.setBackground(Color.WHITE);

        textArea.setForeground(Color.BLACK);

        rightPanel.add(textArea);

        updateTextArea();

        this.add(rightPanel);

        bottomPanel = new JPanel();
        bottomPanel.setBounds(0, 620, 1000, 80);
        bottomPanel.setLayout(null);
        this.add(bottomPanel);

        this.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == addBtn) {

            if(!name.getText().isEmpty() && !id.getText().isEmpty()) {
                Customer c = new Customer(
                        name.getText(),
                        id.getText(),
                        phoneNumber.getText(),
                        productName.getText()
                );
                customers.insert(c);
                updateTextArea();
                
                // You can keep auto-save here, or remove it if you only want the button to save
                FileIO.saveInFile(customers.getAllCustomersAsString());
                
                clearLabels();
            } else {
                 JOptionPane.showMessageDialog(this, "Please fill in fields", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }

       if(e.getSource() == deleteBtn)
    {
    String customerId = id.getText();

    Customer c = customers.getById(customerId);

    if(c != null)
    {
        customers.removeById(customerId);

        JOptionPane.showMessageDialog(this,
        "Customer Deleted");

        updateTextArea();

        FileIO.saveInFile(
        customers.getAllCustomersAsString()
        );
    }

    else
    {
        JOptionPane.showMessageDialog(this,
        "Customer Not Found");
    }
}
        if (e.getSource() == updateBtn) {
            Customer tempC = new Customer(
                    name.getText(),
                    id.getText(),
                    phoneNumber.getText(),
                    productName.getText()
            );
            Customer c = customers.getById(id.getText());
            
            if (c != null) {
                customers.removeById(id.getText());
                customers.insert(tempC);
                updateTextArea();
                
                FileIO.saveInFile(customers.getAllCustomersAsString());

                JOptionPane.showMessageDialog(this, "Information Updated");
            } else {
                JOptionPane.showMessageDialog(this, "Customer Not Found", "Warning", JOptionPane.ERROR_MESSAGE);
            }
            clearLabels();
        }

        // --- 3. Save Button Logic ---
        if (e.getSource() == saveBtn) {
            FileIO.saveInFile(customers.getAllCustomersAsString());
            JOptionPane.showMessageDialog(this, "All Data Saved to File Successfully!");
        }

        if (e.getSource() == clear) {
            clearLabels();
        }
    }

    public void updateTextArea() {
        textArea.setText(customers.getAllCustomersAsString());
    }

    public void clearLabels() {
        name.setText("");
        id.setText("");
        phoneNumber.setText("");
        productName.setText("");
    }
}