import GUI.Product;
public class Start {
    public static void main(String[] args) {
        new Product();
    }
}