package Entity;

public class CustomerList {
    private Customer customers[];

    public CustomerList() {
        customers = new Customer[500];
    }
    
    public CustomerList(int size) {
        customers = new Customer[size];
    }

    public void insert(Customer c) {
        for (int i = 0; i < customers.length; i++) {
            if (customers[i] == null) {
                customers[i] = c;
                break;
            }
        }
    }

   public void removeById(String id)
{
    for(int i = 0; i < customers.length; i++)
    {
        if(customers[i] != null)
        {
            if(customers[i].getId().trim().equals(id.trim()))
            {
                customers[i] = null;
                break;
            }
        }
    }
}
    public Customer getById(String id)
    {
    for(int i = 0; i < customers.length; i++)
    {
        if(customers[i] != null)
        {
            if(customers[i].getId().trim().equals(id.trim()))
            {
                return customers[i];
            }
        }
    }

    return null;
}

    public String getAllCustomersAsString() {
        String s = "";
        for (Customer c : customers) {
            if (c != null) {
                s += c.getCustomerAsString() + "\n";
            }
        }
        return s;
    }

    public Customer[] getAllCustomersArray() {
        return customers;
    }
}