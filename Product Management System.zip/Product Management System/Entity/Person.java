package Entity;

public abstract class Person {
    private String name;
    private String id;
    private String phoneNumber; // Changed from int age to String phoneNumber

    public Person() {}

    public Person(String name, String id, String phoneNumber) {
        setName(name);
        setId(id);
        setPhoneNumber(phoneNumber);
    }

    public void setName(String name) { this.name = name; }
    public String getName() { return name; }

    public void setId(String id) { this.id = id; }
    public String getId() { return id; }

    public void setPhoneNumber(String phoneNumber) { this.phoneNumber = phoneNumber; }
    public String getPhoneNumber() { return phoneNumber; }

    public void showAllDetails() {
        System.out.println("Name: " + getName());
        System.out.println("ID: " + getId());
        System.out.println("Phone: " + getPhoneNumber());
    }
}