package Entity;

public class Customer extends Person {
    private String productName; // Renamed from branch

    public Customer() {}

    public Customer(String name, String id, String phoneNumber, String productName) {
        super(name, id, phoneNumber);
        setProductName(productName);
    }

    public void setProductName(String productName) { this.productName = productName; }
    public String getProductName() { return productName; }

    public void showAllDetails() {
        super.showAllDetails();
        System.out.println("Product Name: " + productName);
    }

    public String getCustomerAsString() {
        return "---------------------------\n" +
               "Customer Name: " + getName() + "\n" +
               "Product ID: " + getId() + "\n" +
               "Phone Number: " + getPhoneNumber() + "\n" +
               "Product Name: " + productName + "\n" +
               "---------------------------\n";
    }
}