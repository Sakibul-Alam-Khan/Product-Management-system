package File;

import java.io.*;
import java.util.Scanner;

public class FileIO {
    
    public static void saveInFile(String data) {
        try {
            // ফাইলটি যেখানে সেভ হবে তার লোকেশন (File ফোল্ডারের ভেতর data.txt)
            File file = new File("File/data.txt");

            // যদি 'File' ফোল্ডারটি না থাকে, তবে এটি তৈরি করে নেবে
            if (file.getParentFile() != null) {
                file.getParentFile().mkdirs();
            }

            // ফাইল রাইটার তৈরি করা হচ্ছে (আগের ভুলটি এখানে ঠিক করা হয়েছে)
            FileWriter writer = new FileWriter(file, false); 
            
            writer.write(data + "\n");
            writer.flush();
            writer.close();
            
        } catch (FileNotFoundException e) {
            System.out.println("Cannot Find File (Directory issue).");
            e.printStackTrace();
        } catch (IOException e) {
            System.out.println("Cannot Write to File.");
            e.printStackTrace();
        }
    }
}